package com.kursach.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import static org.neo4j.driver.Values.parameters;

import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;


@SpringBootApplication
public class ExampleApplication implements AutoCloseable{
	private final Driver driver;

	public ExampleApplication() {
        driver = GraphDatabase.driver("bolt://localhost:7687", AuthTokens.basic("neo4j", "0000"));
    }

	@Override
    public void close() throws Exception {
        driver.close();
    }


	public void printGreeting(final String message) {
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(tx -> {
                Result result = tx.run(
                        "CREATE (a:Greeting) " 
                        + "SET a.message = $message "
                        + "RETURN a.message + ', from node ' + id(a)",
                        parameters("message", message));
                return result.single().get(0).asString();
            });
            System.out.println(greeting);
        }
    }



	public static void main(String[] args) throws Exception {
		try (ExampleApplication greeter = new ExampleApplication()) {
            greeter.printGreeting("hello, world");
        }
		
		SpringApplication.run(ExampleApplication.class, args);
	}

}
